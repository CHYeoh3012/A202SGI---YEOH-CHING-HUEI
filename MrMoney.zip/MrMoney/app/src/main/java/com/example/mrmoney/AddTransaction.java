package com.example.mrmoney;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Locale;


public class AddTransaction extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText datePicker;
    Calendar myCalendar;

    // save transaction data
    public String trans, date, method, item, note;
    public double amount;

    //Initialize DatabaseHelper
    DatabaseHelper databaseHelper = new DatabaseHelper(AddTransaction.this);

    int transID;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        transID = getIntent().getIntExtra(Home_Activity.KEY_EXTRA_CONTACT_ID, 0);
        setContentView(R.layout.add_transaction);

        final View incomeView = findViewById(R.id.relativeLayout2);
        final View expenseView = findViewById(R.id.relativeLayout);
        datePicker = findViewById(R.id.date_picker_actions);
        Spinner spinnerMethod = findViewById(R.id.method_spinner);
        final Spinner spinnerItem = findViewById(R.id.item_spinner);
        final TextView incomeValue = findViewById(R.id.income);
        final TextView expenseValue = findViewById(R.id.expense);
        final EditText amountValue = findViewById(R.id.amount);
        final EditText noteValue = findViewById(R.id.note);
        final Button saveBtn = findViewById(R.id.save);
        final Button updateBtn = findViewById(R.id.update);
        updateBtn.setVisibility(View.INVISIBLE);
        final Button deleteBtn = findViewById(R.id.delete);
        deleteBtn.setVisibility(View.INVISIBLE);

        // For edit list item
        if(transID > 0) {
            saveBtn.setVisibility(View.GONE);
            updateBtn.setVisibility(View.VISIBLE);
            deleteBtn.setVisibility(View.VISIBLE);

            Cursor cursor = databaseHelper.getTransaction(transID);
            cursor.moveToFirst();
            String curTransaction_type = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DATA_COLUMN_TRANSACTION));
            String curNote = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DATA_COLUMN_NOTE));
            double curAmount = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.DATA_COLUMN_AMOUNT));
            if (!cursor.isClosed()) {
                cursor.close();
            }

            if (curTransaction_type.equals("Income"))
            {
                incomeView.setBackgroundResource(R.drawable.ic_folder_open_blue);
                incomeView.setSelected(false);
                expenseView.setBackgroundResource(R.drawable.ic_folder_open_black);
                expenseView.setSelected(true);
                trans = incomeValue.getText().toString(); // for data saving
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                        R.array.income_array, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerItem.setAdapter(adapter);
            }
            else if (curTransaction_type.equals("Expense"))
            {
                expenseView.setBackgroundResource(R.drawable.ic_folder_open_blue);
                expenseView.setSelected(false);
                incomeView.setBackgroundResource(R.drawable.ic_folder_open_black);
                incomeView.setSelected(true);
                trans = expenseValue.getText().toString(); // for data saving
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                        R.array.expense_array, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerItem.setAdapter(adapter);
            }
//            spinnerMethod.setSelection();
//            spinnerItem.setOnItemSelectedListener(this);
            amountValue.setText(String.format(Locale.getDefault(), "%.2f", curAmount));
            noteValue.setText(curNote);
        }

        // Pick date
        myCalendar = Calendar.getInstance();
        final DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };

        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddTransaction.this, dateSetListener, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // Income - TextView change state
        incomeView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.isSelected())
                {
                    v.setBackgroundResource(R.drawable.ic_folder_open_blue);
                    v.setSelected(false);
                    expenseView.setBackgroundResource(R.drawable.ic_folder_open_black);
                    expenseView.setSelected(true);
                    trans = incomeValue.getText().toString(); // for data saving
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                            R.array.income_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerItem.setAdapter(adapter);
                }
                else
                {
                    v.setBackgroundResource(R.drawable.ic_folder_open_black);
                    v.setSelected(true);
                    trans = null;
                }
            }
        });

        // Expense - TextView change state
        expenseView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.isSelected())
                {
                    v.setBackgroundResource(R.drawable.ic_folder_open_blue);
                    v.setSelected(false);
                    incomeView.setBackgroundResource(R.drawable.ic_folder_open_black);
                    incomeView.setSelected(true);
                    trans = expenseValue.getText().toString(); // for data saving
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                            R.array.expense_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerItem.setAdapter(adapter);
                }
                else
                {
                    v.setBackgroundResource(R.drawable.ic_folder_open_black);
                    v.setSelected(true);
                    trans = null;
                }
            }
        });

        // Spinner
        spinnerMethod.setOnItemSelectedListener(this);
        spinnerItem.setOnItemSelectedListener(this);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (trans != null){
                    if (amountValue.getText().toString().equals(""))
                        amountValue.setError("Amount is required!");
                    else{
                        saveBtn.setBackgroundResource(R.drawable.ic_folder_open_blue);
                        amount = Double.parseDouble(amountValue.getText().toString());
                        note = noteValue.getText().toString();

                        if (databaseHelper.insertTrans(trans, date, method, item, note, amount))
                        {
                            Toast.makeText(getApplicationContext(), "Transaction saved", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Failed to save transaction ",
                                    Toast.LENGTH_SHORT).show();
                        }

                        Intent intent = new Intent(AddTransaction.this, Home_Activity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                }
                else
                    Toast.makeText(getApplicationContext(), "Failed to save transaction. Please select income/expense.",
                            Toast.LENGTH_SHORT).show();
            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBtn.setBackgroundResource(R.drawable.ic_folder_open_blue);
                amount = Double.parseDouble(amountValue.getText().toString());
                note = noteValue.getText().toString();

                if (databaseHelper.updateTrans(transID, trans, date, method, item, note, amount))
                {
                    Toast.makeText(getApplicationContext(), "Transaction updated", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Failed to update transaction ", Toast.LENGTH_SHORT).show();
                }

                Intent intent = new Intent(AddTransaction.this, Home_Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteBtn.setBackgroundResource(R.drawable.ic_folder_open_blue);
                databaseHelper.deleteTrans(transID);

                Intent intent = new Intent(AddTransaction.this, Home_Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    // date picker
    private void updateLabel() {
        String myFormat = "dd/MM/yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        datePicker.setText(sdf.format(myCalendar.getTime()));
        date = sdf.format(myCalendar.getTime()); // for data saving
    }

    //spinner
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId() == R.id.method_spinner)
        {
            //            Toast.makeText(this, "Selected: " + item, Toast.LENGTH_SHORT).show();
            this.method = parent.getSelectedItem().toString();
        }
        else if (parent.getId() == R.id.item_spinner)
        {
            //            Toast.makeText(this, "Selected: " + item, Toast.LENGTH_SHORT).show();
            this.item = parent.getSelectedItem().toString();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

//                sp = getSharedPreferences("Transaction", Context.MODE_PRIVATE);
//                editor = sp.edit();
//                editor.putString("Data", transData.toString());
//                editor.commit();

//            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.income_array, android.R.layout.simple_spinner_item);
//            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//            spinnerItem.setAdapter(adapter);
//            spinnerItem.setOnItemSelectedListener(this);

//Edit Data
//            String curDate = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DATA_COLUMN_DATE));
//            String curMethod = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DATA_COLUMN_METHOD));
//            String curItem = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DATA_COLUMN_ITEM));