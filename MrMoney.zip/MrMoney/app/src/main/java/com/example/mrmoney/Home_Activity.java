package com.example.mrmoney;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

public class Home_Activity extends AppCompatActivity {

    public final static String KEY_EXTRA_CONTACT_ID = "KEY_EXTRA_CONTACT_ID";

    FloatingActionButton addBtn;
    CalendarView calendarView;
    ListView transaction;

    //SQLite Database
    DatabaseHelper databaseHelper;

    //Toolbar and Navigation Drawer
    Toolbar toolbar;
    DrawerLayout dl;
    ActionBarDrawerToggle barDrawerToggle;

//    static int msg;
//    String curYear, curMonth, curDay;
//    SharedPreferences sp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        addBtn = findViewById(R.id.add);
        calendarView = findViewById(R.id.calendarView);
        transaction = findViewById(R.id.transDetail);
        toolbar = findViewById(R.id.toolbar);

        toolbar.setTitle("Transaction"); //set toolbar's title
        toolbar.setTitleTextColor(getColor(R.color.white));

        dl = findViewById(R.id.dl);
        barDrawerToggle = new ActionBarDrawerToggle(this, dl, toolbar, R.string.open, R.string.close);
        barDrawerToggle.setDrawerIndicatorEnabled(true);

        dl.addDrawerListener(barDrawerToggle);
        barDrawerToggle.syncState();
        if(getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        NavigationView navView = findViewById(R.id.navBar);
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.transaction)
                {
                    Toast.makeText(getApplicationContext(), "Transaction", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Home_Activity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    //onResume() ??
                }
                else if (id == R.id.statistics)
                {
                    Toast.makeText(getApplicationContext(), "Statistics", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Statistics.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                else if (id == R.id.setting)
                {
                    Toast.makeText(getApplicationContext(), "Setting", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Settings.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                return true;
            }
        });

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTransaction();
            }
        });

        displayTrans();

//        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
//            @Override
//            public void handleOnBackPressed() {
//                finish();
//            }
//        };
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return barDrawerToggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }

    public void displayTrans()
    {
        databaseHelper = new DatabaseHelper(this);
        String [] columns = new String[] { //                DatabaseHelper.PERSON_COLUMN_ID,
                DatabaseHelper.DATA_COLUMN_TRANSACTION,
                DatabaseHelper.DATA_COLUMN_DATE,
                DatabaseHelper.DATA_COLUMN_METHOD,
                DatabaseHelper.DATA_COLUMN_ITEM,
                DatabaseHelper.DATA_COLUMN_NOTE,
                DatabaseHelper.DATA_COLUMN_AMOUNT
        };
        int [] widgets = new int[] {//                R.id.trans_id,
                R.id.trans_type,
                R.id.trans_date,
                R.id.trans_method,
                R.id.trans_item,
                R.id.trans_note,
                R.id.trans_amount
        };
        Cursor cursor = databaseHelper.getAllTransactions();
        SimpleCursorAdapter cursorAdapter = new SimpleCursorAdapter(this, R.layout.transaction_info,
                cursor, columns, widgets, 0);
        transaction = findViewById(R.id.transDetail);
        transaction.setAdapter(cursorAdapter);
        transaction.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView listView, View view,
                                    int position, long id) {
                Cursor itemCursor = (Cursor) Home_Activity.this.transaction.getItemAtPosition(position);
                int dataID = itemCursor.getInt(itemCursor.getColumnIndex(DatabaseHelper.DATA_COLUMN_ID));
                Intent intent = new Intent(getApplicationContext(), AddTransaction.class);
                intent.putExtra(KEY_EXTRA_CONTACT_ID, dataID);
                startActivity(intent);
            }
        });

//        //refresh ListView Data
//        transaction.invalidateViews();
//        transaction.refreshDrawableState();
    }

    public void addTransaction()
    {
        Intent i = new Intent(getApplicationContext(), AddTransaction.class);
        i.putExtra(KEY_EXTRA_CONTACT_ID, 0);
        startActivity(i);
    }

    public void onBackPressed(){
        Toast.makeText(getApplicationContext(), "Exit App", Toast.LENGTH_SHORT).show();
        finishAndRemoveTask();
        finishAffinity();
        finish();
    }

}

//calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
//
//@Override
//public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
//        curYear = String.valueOf(year);
//        curMonth = String.valueOf(month);
//        curDay = String.valueOf(dayOfMonth);
////                Toast.makeText(getApplicationContext(), "Year: " + curYear, Toast.LENGTH_SHORT).show();
////                if (curYear.equals(transaction.getDate().substring(7,8)))
//        }
//        });

//        sp = getApplicationContext().getSharedPreferences("Transaction", Context.MODE_PRIVATE);
//        transaction.setText(sp.getString("Data", ""));

//        String msg = getIntent().getStringExtra("msg");
//        Toast.makeText(getApplicationContext(), "msg: " + msg, Toast.LENGTH_SHORT).show();