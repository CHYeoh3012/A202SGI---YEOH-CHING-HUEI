package com.example.mrmoney;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Statistics extends AppCompatActivity {

    // Toolbar and Navigation drawer
    Toolbar toolbar;
    DrawerLayout dl;
    ActionBarDrawerToggle barDrawerToggle;

    // Pie Chart
    AnyChartView chartView;
    String[] item;
    double[] amount;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistics);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Statistics"); //set toolbar's title
        toolbar.setTitleTextColor(getColor(R.color.white));

        dl = findViewById(R.id.dl);
        barDrawerToggle = new ActionBarDrawerToggle(this, dl, toolbar, R.string.open, R.string.close);
        barDrawerToggle.setDrawerIndicatorEnabled(true);

        dl.addDrawerListener(barDrawerToggle);
        barDrawerToggle.syncState();
        if(getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        NavigationView navView = findViewById(R.id.navBar);
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.transaction)
                {
                    Toast.makeText(getApplicationContext(), "Transaction", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Home_Activity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                else if (id == R.id.statistics)
                {
                    Toast.makeText(getApplicationContext(), "Statistics", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Statistics.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                else if (id == R.id.setting)
                {
                    Toast.makeText(getApplicationContext(), "Setting", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Settings.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                return true;
            }
        });

        chartView = findViewById(R.id.chart);
        setupPieChart();
    }

    private void setupPieChart() {
        Pie pie = AnyChart.pie();
        List<DataEntry> dataEntries = new ArrayList<>();
        DatabaseHelper databaseHelper = new DatabaseHelper(this);

        item = databaseHelper.getAllItem();
        amount = databaseHelper.getAllAmount();

        int j = (item.length-1);
        for (int i=0; i<=j; i++)
        {
            for (j=(item.length-1); j>=i; j--){
                if (item[i].equals(item[j]) && i != j){
                    amount[i] = amount[i] + amount[j];
                    amount[j] = 0;
                }
            }
            if (amount[i] != 0)
                dataEntries.add(new ValueDataEntry(item[i], amount[i]));
            j = (item.length-1);
        }
        pie.data(dataEntries);
        chartView.setChart(pie);
    }

    public void onBackPressed()
    {
        startActivity(new Intent(getApplicationContext(), Home_Activity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
    }
}

//Not in use :
//    String[] months = {"Jan", "Feb", "Mar"};
//    int[] earning = {500, 800, 2000};
//            dataEntries.add(new ValueDataEntry(months[i], earning[i]));

//void setupPieChart()
//Below is for checking
//        for (double a : amount){
//            Toast.makeText(this, String.format(Locale.getDefault(), "%.2f",a), Toast.LENGTH_SHORT).show();
//        }
//Below is for checking
//        for (String i : item) {
//            Toast.makeText(this, i, Toast.LENGTH_SHORT).show();
//        }
//Toast.makeText(getApplicationContext(), "amount[i]: " + i, Toast.LENGTH_SHORT).show();