package com.example.mrmoney;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.goodiebag.pinview.Pinview;
import com.google.android.material.navigation.NavigationView;

public class Settings extends AppCompatActivity {

    // Toolbar and Navigation drawer
    Toolbar toolbar;
    DrawerLayout dl;
    ActionBarDrawerToggle barDrawerToggle;

    Switch pinSwitch;
    Pinview pinview;

    //Shared Preference for save pin code
    SharedPreferences sp;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Setting"); //set toolbar's title
        toolbar.setTitleTextColor(getColor(R.color.white));

        dl = findViewById(R.id.dl);
        barDrawerToggle = new ActionBarDrawerToggle(this, dl, toolbar, R.string.open, R.string.close);
        barDrawerToggle.setDrawerIndicatorEnabled(true);

        dl.addDrawerListener(barDrawerToggle);
        barDrawerToggle.syncState();
        if(getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        NavigationView navView = findViewById(R.id.navBar);
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.transaction)
                {
                    Toast.makeText(getApplicationContext(), "Transaction", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Home_Activity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    //onResume() ??
                }
                else if (id == R.id.statistics)
                {
                    Toast.makeText(getApplicationContext(), "Statistics", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Statistics.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                else if (id == R.id.setting)
                {
                    Toast.makeText(getApplicationContext(), "Setting", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Settings.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                return true;
            }
        });

        pinSwitch = findViewById(R.id.pin_switch);
        pinview = findViewById(R.id.pinview);

        sp = getSharedPreferences("PinCode", MODE_PRIVATE);
        String pin = sp.getString("Pin", null);
        if (pin != null)
        {
            pinSwitch.setChecked(true);
            pinview.setVisibility(View.VISIBLE);
        }
        else
            pinSwitch.setChecked(false);

        pinSwitch.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (pinSwitch.isChecked()){
                    pinview.setVisibility(View.VISIBLE);
                }
                else
                {
                    pinview.setVisibility(View.INVISIBLE);
                    editor = sp.edit();
                    editor.remove("Pin");
                    editor.apply();
                }
            }
        });

        pinview.setPinViewEventListener(new Pinview.PinViewEventListener() {
            @Override
            public void onDataEntered(Pinview pinview, boolean fromUser) {
                sp = getSharedPreferences("PinCode", Context.MODE_PRIVATE);
                editor = sp.edit();
                editor.putString("Pin", pinview.getValue());
                editor.apply();
                Toast.makeText(getApplicationContext(), "New Pin Set", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onBackPressed()
    {
        startActivity(new Intent(getApplicationContext(), Home_Activity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
    }
}
