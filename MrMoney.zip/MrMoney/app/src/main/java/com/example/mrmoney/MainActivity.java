package com.example.mrmoney;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity{
    //SharedPreferences for retrieve pin code
    SharedPreferences sp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getSharedPreferences("PinCode", MODE_PRIVATE);
//        String pin = sp.getString("Pin", null);
//        Toast.makeText(getApplicationContext(), sp.getString("Pin", null), Toast.LENGTH_SHORT).show();
        if (sp.getString("Pin", null) == null) {
//            Toast.makeText(getApplicationContext(), "Entering Home", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), Home_Activity.class);
            startActivity(intent);
        }
        else{
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
        }
    }
}