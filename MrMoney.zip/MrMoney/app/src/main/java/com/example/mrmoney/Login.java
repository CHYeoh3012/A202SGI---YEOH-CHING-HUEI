package com.example.mrmoney;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.goodiebag.pinview.Pinview;

public class Login extends AppCompatActivity {

    //SharedPreferences for retrieve pin code
    SharedPreferences sp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pin_login);

        Pinview pinview_login = findViewById(R.id.pinview_login);
        pinview_login.setPinViewEventListener(new Pinview.PinViewEventListener() {
            @Override
            public void onDataEntered(Pinview pinview_login, boolean fromUser) {
                sp = getSharedPreferences("PinCode", MODE_PRIVATE);
                String pin = sp.getString("Pin", null);
                if (pin.equals(pinview_login.getValue()))
                {
                    Intent intent = new Intent(getApplicationContext(), Home_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
                else
                    Toast.makeText(getApplicationContext(), "Wrong Pin", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onBackPressed(){
        Toast.makeText(getApplicationContext(), "Exit App", Toast.LENGTH_SHORT).show();
        finishAndRemoveTask();
        finishAffinity();
        finish();
    }
}
