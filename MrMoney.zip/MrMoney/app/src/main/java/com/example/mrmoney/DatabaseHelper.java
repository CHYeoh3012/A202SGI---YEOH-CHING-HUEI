package com.example.mrmoney;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    //Initialize Database Name and Table Name
    private SQLiteDatabase sqLiteDatabase;
    private static final String DATABASE_NAME = "MoneyTransaction.db";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_NAME = "Transaction_Details";

    static final String DATA_COLUMN_ID = "_id";
    static final String DATA_COLUMN_TRANSACTION = "transaction_type";
    static final String DATA_COLUMN_DATE = "date";
    static final String DATA_COLUMN_METHOD = "method";
    static final String DATA_COLUMN_ITEM = "item";
    static final String DATA_COLUMN_AMOUNT = "amount";
    static final String DATA_COLUMN_NOTE = "note";

    DatabaseHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(" + DATA_COLUMN_ID + " INTEGER PRIMARY KEY, " +
                DATA_COLUMN_TRANSACTION + " TEXT, " + DATA_COLUMN_DATE + " TEXT, " + DATA_COLUMN_METHOD +
                " TEXT, " + DATA_COLUMN_ITEM + " TEXT, " + DATA_COLUMN_NOTE + " TEXT, " + DATA_COLUMN_AMOUNT + " double)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop older table if exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    boolean insertTrans(String transaction_type, String date, String method, String item, String note, double amount)
    {
        sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATA_COLUMN_TRANSACTION, transaction_type);
        contentValues.put(DATA_COLUMN_DATE, date);
        contentValues.put(DATA_COLUMN_METHOD, method);
        contentValues.put(DATA_COLUMN_ITEM, item);
        contentValues.put(DATA_COLUMN_NOTE, note);
        contentValues.put(DATA_COLUMN_AMOUNT, amount);
        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
        return true;
    }

    boolean updateTrans(Integer id, String transaction_type, String date, String method, String item, String note,
                        double amount) {
        sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATA_COLUMN_TRANSACTION, transaction_type);
        contentValues.put(DATA_COLUMN_DATE, date);
        contentValues.put(DATA_COLUMN_METHOD, method);
        contentValues.put(DATA_COLUMN_ITEM, item);
        contentValues.put(DATA_COLUMN_NOTE, note);
        contentValues.put(DATA_COLUMN_AMOUNT, amount);
        sqLiteDatabase.update(TABLE_NAME, contentValues, DATA_COLUMN_ID + " = ? ", new String[]
                { Integer.toString(id) } );
        return true;
    }

    Integer deleteTrans(Integer id) {
        sqLiteDatabase = this.getWritableDatabase();
        return sqLiteDatabase.delete(TABLE_NAME,
                DATA_COLUMN_ID + " = ? ", new String[] { Integer.toString(id) });
    }

    Cursor getTransaction(int id) {
        sqLiteDatabase = this.getReadableDatabase();
        return sqLiteDatabase.rawQuery( "SELECT * FROM " + TABLE_NAME + " WHERE " +
                DATA_COLUMN_ID + "=?", new String[] { Integer.toString(id) } );
    }
    Cursor getAllTransactions() {
        sqLiteDatabase = this.getReadableDatabase();
        return sqLiteDatabase.rawQuery( "SELECT * FROM " + TABLE_NAME, null );
    }

    String[] getAllItem() {
        sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery( "SELECT " + DATA_COLUMN_ITEM + " FROM " + TABLE_NAME ,
                null );
        String[] allItem = new String[cursor.getCount()];
        int i=0;
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            allItem[i] = cursor.getString(0);
            i++;
        }
        cursor.close();
        return allItem;
    }

    double[] getAllAmount() {
        sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery( "SELECT " + DATA_COLUMN_AMOUNT + " FROM " + TABLE_NAME ,
                 null );
        double[] allAmount = new double[cursor.getCount()];
        int i=0;
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            allAmount[i] = cursor.getDouble(0);
            i++;
        }
        cursor.close();
        return allAmount;
    }
}
